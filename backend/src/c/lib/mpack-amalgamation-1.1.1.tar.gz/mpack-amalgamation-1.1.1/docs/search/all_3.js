var searchData=
[
  ['feature_20comparisons_0',['Feature Comparisons',['../md_docs_features.html',1,'']]]
];
