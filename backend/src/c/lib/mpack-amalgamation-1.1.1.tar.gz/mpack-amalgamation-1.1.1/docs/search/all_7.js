var searchData=
[
  ['protocol_20clarifications_0',['Protocol Clarifications',['../md_docs_protocol.html',1,'']]]
];
