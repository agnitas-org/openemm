var searchData=
[
  ['reader_20api_0',['Reader API',['../group__reader.html',1,'']]]
];
