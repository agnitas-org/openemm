var searchData=
[
  ['configuration_20options_0',['Configuration Options',['../group__config.html',1,'']]]
];
