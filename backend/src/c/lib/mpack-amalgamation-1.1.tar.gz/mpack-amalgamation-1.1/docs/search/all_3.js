var searchData=
[
  ['feature_20comparisons_3',['Feature Comparisons',['../md_docs_features.html',1,'']]]
];
