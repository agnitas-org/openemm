var searchData=
[
  ['protocol_20clarifications_417',['Protocol Clarifications',['../md_docs_protocol.html',1,'']]]
];
