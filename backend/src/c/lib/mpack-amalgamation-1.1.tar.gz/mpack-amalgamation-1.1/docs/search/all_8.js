var searchData=
[
  ['reader_20api_418',['Reader API',['../group__reader.html',1,'']]]
];
