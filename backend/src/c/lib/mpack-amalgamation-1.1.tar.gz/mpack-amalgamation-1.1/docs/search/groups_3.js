var searchData=
[
  ['reader_20api_784',['Reader API',['../group__reader.html',1,'']]]
];
