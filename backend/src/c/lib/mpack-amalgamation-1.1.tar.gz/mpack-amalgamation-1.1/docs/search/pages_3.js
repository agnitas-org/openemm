var searchData=
[
  ['protocol_20clarifications_790',['Protocol Clarifications',['../md_docs_protocol.html',1,'']]]
];
