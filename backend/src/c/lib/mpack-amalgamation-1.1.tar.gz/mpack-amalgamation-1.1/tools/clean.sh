#!/bin/sh
rm -rf .build
rm -f vgcore.* mpack-*.tar.gz *.gcov *.gcno src/mpack/*.o README.html
